function [ ] = MISAGA_D( )
%Distributed Version of MISAGA

fprintf('Loading graph data and node attributes...\n'); 

path = '';
P = load('Configuration');
K = P(1);
alpha = P(2);
Max_Iter = P(3);
Mini_Gap=P(4);
lambda = P(5);


[Y,F,Nv,~] = Loadedgelist_C( );
A = Proximal_Matrix(F,1);
A = A - diag(diag(A));

Y = full(Y);
A = full(A);

fprintf('Data loaded, now initializing indicator matrices...\n');

%Initializing Cluster indicator matrix
C = rand(Nv,K); C = C./repmat(sum(C,2),1,K); C_old = C;
%Initializing indicator matrix of structure strength
D = rand(Nv,K); 
%Initializing indicator matrix of attribute association strength
B = rand(Nv,K);
matrix_E = ones(Nv,K);
e = 1.0e-25;

%Vector for recording objective values after each iteration of updating.
Objective = (1:Max_Iter);

fprintf('Optimization process begins...\n');
tic;
for i=1:Max_Iter
    
    %Updating Cluster indicator matrix
    C = C.*((alpha*Y*D+(1-alpha)*A*B+lambda*matrix_E)./(C*(B'*B)+C*(D'*D)+C+lambda*repmat(sum(C,2),1,K)));
    C(C<e)=e;
    
    %updating B
    B = B.*(((1-alpha)*A*C)./(B*(C'*C)+B));
    B(B<e)=e;
    
    %updating D
    D = D.*((alpha*Y*C)./(D*(C'*C)+D));
    D(D<e)=e;
    
    %compute objective value
    del_G = C-C_old;
    C_old = C;
    Objective(1,i)=sqrt(trace(del_G'*del_G));
    
    if(i>1&&i<Max_Iter)
      if(Objective(1,i)<Mini_Gap)
         Obj = alpha*trace(C'*Y*D)+(1-alpha)*trace(C'*A*B)-0.5*trace(C*(B'*B)*C')-0.5*trace(C*(D'*D)*C')-0.5*trace(C'*C)-0.5*trace(D'*D)-0.5*trace(B'*B)-0.5*lambda*trace((sum(C,2)-ones(Nv,1))'*(sum(C,2)-ones(Nv,1)));
         fprintf('The variation of cluster membership matrix G after iteration %d is less than Minimum Gap %f, the algorithm is terminated.\n', i, Mini_Gap);
         fprintf('The final objective value is %f.\n', Obj);
         Objective = Objective(1,1:i);
         break;
      end
      if(mod(i,50)==0)
          Obj = alpha*trace(C'*Y*D)+(1-alpha)*trace(C'*A*B)-0.5*trace(C*(B'*B)*C')-0.5*trace(C*(D'*D)*C')-0.5*trace(C'*C)-0.5*trace(D'*D)-0.5*trace(B'*B)-0.5*lambda*trace((sum(C,2)-ones(Nv,1))'*(sum(C,2)-ones(Nv,1)));
          fprintf('The objective value after iteration %d is %f.\n', i, Obj);
      end 
    else
       Obj = alpha*trace(C'*Y*D)+(1-alpha)*trace(C'*A*B)-0.5*trace(C*(B'*B)*C')-0.5*trace(C*(D'*D)*C')-0.5*trace(C'*C)-0.5*trace(D'*D)-0.5*trace(B'*B)-0.5*lambda*trace((sum(C,2)-ones(Nv,1))'*(sum(C,2)-ones(Nv,1)));
       fprintf('The objective value after iteration %d is %f.\n', i, Obj);
   end
end

time = toc;
fprintf('Optimization is done, saving recording information and indicator matrices...\n');

C(C<=e)=0;
B(B<=e)=0;
D(D<=e)=0;
path = strcat('.\',path,'\');
prefix=strcat('K=',num2str(K));
dlmwrite(strcat(path,prefix,'_C'),C);
dlmwrite(strcat(path,prefix,'_D'),D);
dlmwrite(strcat(path,prefix,'_B'),B);

fid = fopen(strcat(path,prefix,'.log'), 'w');
fprintf(fid, 'Parameters setting:\n');
fprintf(fid, 'Alpha:%s\te:%s\tK:%s\tMini_Gap:%s\tLambda:%s\n',num2str(alpha),num2str(e),num2str(K),num2str(Mini_Gap),num2str(lambda));
fprintf(fid, 'Optimization Time: %s\n', num2str(time));
fprintf(fid, 'Total time consumption: %s\n', num2str(time));
fprintf(fid, 'The number of iterations: %s\n', num2str(size(Objective,2)));
fprintf(fid, 'Time consumption per iteration: %s\n', num2str(time/size(Objective,2)));

fclose(fid);
fprintf('Recording information and indicator matrices saved.\n');

fprintf('Identifying clusters...\n');

% ordinary attributed graph
Identify_Cluster_Base(C,path);

fprintf('Job Done.\n');

end

function [ D,F,n,m ] = Loadedgelist_C( )
% Load edgelist and construct matrices for DCNLA
info= load('statistics');
n = info(1,1);
m = info(3,1);
edgelist=load('edgelist');
edgelist=edgelist+1;
D = sparse(cat(1,edgelist(:,1),edgelist(:,2)),cat(1,edgelist(:,2),edgelist(:,1)),ones(size(cat(1,edgelist(:,1),edgelist(:,2)),1),1),n,n);

similaritylist=load('vertex2aid');
similaritylist(:,1)=similaritylist(:,1)+1;
similaritylist(:,2)=similaritylist(:,2)+1;
%A = sparse(cat(1,similaritylist(:,1),similaritylist(:,2)),cat(1,similaritylist(:,2),similaritylist(:,1)),cat(1,similaritylist(:,3),similaritylist(:,3)),Nv,Nv);

F = sparse(similaritylist(:,2),similaritylist(:,1),ones(size(similaritylist,1),1),m, n);

end

function [cluster_number] = Identify_Cluster_Base(G,path,A,mini_size,phi,tau)
%   This function is used to identify Clusters after the matrix of
%   cluster affiliation is obtained.
%   Input: 
%   G, the matrix of weights representing the affliation of
%   clusters(Nv*K); 
%   A: adjacency matrix of network graph; 
%   phi: Gij is set to zero if Gij is lower than phi; 
%   tau: threshold that is used to control the overlapping rate;
%   path: directory to store the cluster file.
%
%   Output: 
%   cluster_number: The number of Clusters in G.

% check parameter setting
if((nargin~=2)&&(nargin~=4)&&(nargin~=6))
    fprintf('Wrong setting of args!\n');
    return;
end
   % G and path is set
if(nargin==2)
    [~,K] = size(G);
	G = G./repmat(max(G,[],2),1,K);
	G(isnan(G))=0;
	G(G<1)=0;
   
    small_clusters=sum(G)<1;
    G = G(:, ~small_clusters);
    X = unique(G','rows');
    G = X';
    [~,K1] = size(G);
    fid = fopen(strcat(path,'K=',num2str(K),'.Cluster'), 'w');
    count = 0;
    for k=1:K1
        index_k = find(G(:,k));
        if(~isempty(index_k))
            count = count + 1;
            fprintf(fid, '%s\n', strcat('Cluster #',num2str(count)));
            for i= 1:length(index_k)
                fprintf(fid, '%s\t',num2str(index_k(i)-1));
            end
            fprintf(fid, '\n');
        end
        
    end
    fclose(fid);
    cluster_number = count;
end

   % G, A, mini_size and path is set
if (nargin==4)
    [N,K] = size(G);
	G = G./repmat(max(G,[],2),1,K);
	G(isnan(G))=0;
	G(G<1)=0;
	count = 1;
	
    for k = 1:K
       index_k = find(G(:,k));   
       [S, C] = graphconncomp(sparse(A(index_k,index_k)));
       for i = 1:S
           temp_G(:,count)=zeros(N,1);       
           temp_G(index_k(C==i),count) = G(index_k(C==i),k);
           count = count + 1;
       end
    end
   
   G = temp_G;
   small_clusters=sum(G)<mini_size;
   G = G(:, ~small_clusters);
   X = unique(G','rows');
   G = X';
   
   fid = fopen(strcat(path,'K=',num2str(K),'_Min_size=',num2str(mini_size),'.Cluster'), 'w');
   for k = 1:size(G,2)
       index_k = find(G(:,k));
       %str = sprintf('%s%s','Cluster #', num2str(k));
       fprintf(fid, '%s\n', strcat('Cluster #',num2str(k)));
       %fprintf(fid, '\n');
       for i= 1:length(index_k)
       fprintf(fid, '%s\t',num2str(index_k(i)-1));
       end
       fprintf(fid, '\n');
   end
   fclose(fid);
   cluster_number = size(G,2);
end

if(nargin==6)
   [N,K] = size(G);
   G(G<phi)=0;
   G = G./repmat(sum(G,2),1,K);
   G(isnan(G))=0;
   G(G>=tau)=1;
   G(G<tau)=0;
   count = 1;
   for k = 1:K
       index_k = find(G(:,k));   
       [S, C] = graphconncomp(sparse(A(index_k,index_k)));
       for i = 1:S
           temp_G(:,count)=zeros(N,1);       
           temp_G(index_k(C==i),count) = G(index_k(C==i),k);
           count = count + 1;
       end
   end
   
   G = temp_G;
   small_clusters=sum(G)<mini_size;
   G = G(:, ~small_clusters);
   X = unique(G','rows');
   G = X';
   fid = fopen(strcat(path,'K=',num2str(K),'_phi=',num2str(phi),'_tau=',num2str(tau),'_Min_size=', num2str(mini_size),'.Cluster'), 'w');

   for k = 1:size(G,2)
       index_k = find(G(:,k));
       fprintf(fid, '%s\n', strcat('Cluster #',num2str(k)));
       for i= 1:length(index_k)
       fprintf(fid, '%s\t',num2str(index_k(i)-1));
       end
       fprintf(fid, '\n');
   end
   fclose(fid);
   cluster_number=size(G,2);
end


end

