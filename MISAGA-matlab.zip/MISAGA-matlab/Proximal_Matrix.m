function [P] = Proximal_Matrix(X,para)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
if para==1
    N = size(X,2);
    
    a = sum(X.^2,1);
    a = sqrt(a);
    P = zeros(N,N);
    for i = 1:N-1
        for j=i+1:N
            pij = X(:,i)'*X(:,j)./max((a(i)*a(j)),1e-10);
            P(i,j)=pij;
            P(j,i)=pij;
            
        end
    end
else
    P = X'*X;
    % sigma = 2 by default
    sigma = 2;
    P = (2*P - repmat(diag(P),1,n)-repmat(diag(P)',n,1))./(2*sigma*sigma);
    P = exp(P);
    P = P-diag(diag(P));
end
clear X;
%P = sparse(P);

end

